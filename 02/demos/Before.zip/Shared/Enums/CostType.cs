﻿namespace Shared.Enums
{
    public enum CostType
    {
        Cheap,
        Moderate,
        Expensive
    }
}